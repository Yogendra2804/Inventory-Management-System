
import json
import csv
import tkinter as tk
from tkinter import messagebox

inventory = {}
item_Id = 1
low_stock_item = set()

class customError(Exception):
    def __init__(self, message="Invalid Input"):
        super().__init__(message)

def load_inventory():
    global inventory, item_Id
    try:
        with open("inventory.json", "r") as f:
            loaded = json.load(f)
            inventory = {int(k): v for k, v in loaded.items()}
        item_Id = max(inventory.keys()) + 1 if inventory else 1
    except FileNotFoundError:
        inventory = {}

def save_inventory():
    with open("inventory.json", "w") as f:
        json.dump(inventory, f, indent=4)

def show_gui_inventory():
    for widget in root.grid_slaves():
        if int(widget.grid_info()["row"]) >= 6:
            widget.destroy()
    row_num = 6
    for id, item in inventory.items():
        label = tk.Label(root, text=f"ID: {id} | Name: {item['name']} | Price: ₹{item['price']} | Qty: {item['quantity']}")
        label.grid(row=row_num, column=0, columnspan=3, pady=2)
        if item["quantity"] <= 5:
            low_stock_item.add(item["name"])
        row_num += 1
    if low_stock_item:
        tk.Label(root, text=f"⚠️ Low Stock Items: {', '.join(low_stock_item)}", fg="red").grid(row=row_num, column=0, columnspan=3)

def add_gui_item():
    global item_Id
    try:
        name = name_label.get().strip()
        price = float(price_label.get())
        quantity = int(quantity_label.get())

        if quantity < 0:
            raise customError("Quantity can't be negative")

        inventory[item_Id] = {"name": name, "price": price, "quantity": quantity}
        if quantity <= 5:
            low_stock_item.add(name)

        messagebox.showinfo("Success", f"Item Added!\nID: {item_Id}\nName: {name}")
        item_Id += 1
        save_inventory()
        show_gui_inventory()
    except ValueError:
        messagebox.showerror("Error", "Invalid input!")
    except customError as e:
        messagebox.showerror("Error", str(e))

def remove_gui_item():
    try:
        id = int(id_label.get())
        if id in inventory:
            del inventory[id]
            save_inventory()
            messagebox.showinfo("Success", f"Item {id} removed.")
            show_gui_inventory()
        else:
            messagebox.showwarning("Not Found", f"No item found with ID {id}")
    except ValueError:
        messagebox.showerror("Error", "Enter a valid ID.")

def update_gui_item():
    try:
        id = int(update_label.get())
        if id in inventory:
            def submit_update():
                try:
                    new_price = float(update_price.get()) if update_price.get() else inventory[id]['price']
                    new_qty = int(update_qty.get()) if update_qty.get() else inventory[id]['quantity']
                    inventory[id]['price'] = new_price
                    inventory[id]['quantity'] = new_qty
                    save_inventory()
                    messagebox.showinfo("Updated", f"Item {id} updated.")
                    show_gui_inventory()
                    update_popup.destroy()
                except:
                    messagebox.showerror("Error", "Invalid values.")

            update_popup = tk.Toplevel(root)
            update_popup.title("Update Item")
            tk.Label(update_popup, text="New Price:").grid(row=0, column=0)
            update_price = tk.Entry(update_popup)
            update_price.grid(row=0, column=1)
            tk.Label(update_popup, text="New Quantity:").grid(row=1, column=0)
            update_qty = tk.Entry(update_popup)
            update_qty.grid(row=1, column=1)
            tk.Button(update_popup, text="Submit", command=submit_update).grid(row=2, column=0, columnspan=2, pady=5)
        else:
            messagebox.showwarning("Not Found", f"No item with ID {id}")
    except ValueError:
        messagebox.showerror("Error", "Enter a valid ID.")

def export_to_csv():
    with open("inventory_export.csv", "w", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(["ID", "Name", "Price", "Quantity"])
        for id, item in inventory.items():
            writer.writerow([id, item["name"], item["price"], item["quantity"]])
    messagebox.showinfo("Exported", "Inventory exported to inventory_export.csv")

def gui_add_form():
    global name_label, price_label, quantity_label
    clear_widgets()
    tk.Label(root, text="Name:").grid(row=6, column=0)
    name_label = tk.Entry(root)
    name_label.grid(row=6, column=1)

    tk.Label(root, text="Price:").grid(row=7, column=0)
    price_label = tk.Entry(root)
    price_label.grid(row=7, column=1)

    tk.Label(root, text="Quantity:").grid(row=8, column=0)
    quantity_label = tk.Entry(root)
    quantity_label.grid(row=8, column=1)

    tk.Button(root, text="Add Item", command=add_gui_item).grid(row=9, column=0, columnspan=2)

def gui_remove_form():
    global id_label
    clear_widgets()
    tk.Label(root, text="Enter ID to remove:").grid(row=6, column=0)
    id_label = tk.Entry(root)
    id_label.grid(row=6, column=1)
    tk.Button(root, text="Remove", command=remove_gui_item).grid(row=7, column=0, columnspan=2)

def gui_update_form():
    global update_label
    clear_widgets()
    tk.Label(root, text="Enter ID to update:").grid(row=6, column=0)
    update_label = tk.Entry(root)
    update_label.grid(row=6, column=1)
    tk.Button(root, text="Update", command=update_gui_item).grid(row=7, column=0, columnspan=2)

def clear_widgets():
    for widget in root.grid_slaves():
        if int(widget.grid_info()["row"]) >= 6:
            widget.destroy()

############################## CPL

def low_stock():
    if len(low_stock_item) != 0 :
        print("\nTHis Items are running low on stock : ")
        for item  in low_stock_item :
            print(item , "\n")
        

def add_item():
        global item_Id 
        try:

            name = input('Enter the name of the item. ')
            price = float(input("Enter the price of the "+ name + " : "))
            quantity = int(input("Enter the quantity of the "+  name +" : "))
            inventory[item_Id] = {
                "name": name, 
                "price": price,
                "quantity": quantity
            }
            if(quantity <  0):
                raise customError("")
            
            print("\n\nItem name : ",name,"\nItem Id : " , item_Id, "\nItem price : ", price , "\nItem quantity : " , quantity)
            item_Id += 1

            if(quantity <= 5):
                low_stock_item.add(name)
            low_stock()
            save_inventory()
        except customError as e:
            print("Cought an Error : Negative Quantity not allowed. -_-  ")

    
def remove_itme():
    id = int(input('Enter the Id of the item you want to remove : '))
        
    if id in inventory:
        del inventory[id]
        print('Item deleated')
    else:
        print('Item not found')
    save_inventory()


def Show_itme():
    for id in inventory:
        item = inventory[id]
        print("\nID : " , id)
        print("Name : ",item["name"])
        print("Price : ",item["price"])
        print("Quantity : ",item["quantity"])
        print("\n")
        
        if(item["quantity"] <= 5):
            low_stock_item.add(item["name"])
    low_stock()
        
    


def Search_item():
    key = int(input('Enter the Id of the item you want to search. \n'))
    if key not in inventory : 
        print("\nNo item present at this Id.\n")
    else:
        print("\nItem found!\n")
        print("Name : " , inventory[key]["name"])
        print("Price : " , inventory[key]["price"])
        print("Quantity : " , inventory[key]["quantity"])
        print("\n")


def Update_item():
    id = int(input("Enter the Id of the element you want to update. "))
    if id in inventory:
        try:
            print("\nFound It ! ")
            print("To update price press 1. ")
            print("To update the quantity of your item press 2.")
            print("To update both press 3. ")
            choice = int(input())
            if(choice > 3):
                raise customError("")
            elif(choice == 1):
                new_price = input("Enter the new Price. ")
                if new_price != "":
                    new_price = float(new_price)
                else:
                    new_price = inventory[id]['price']
                inventory[id]['price'] = new_price
            elif(choice == 2):
                new_quantity = input("Enter the new Quantity. ")
                if new_quantity != "":
                    new_quantity = int(new_quantity)
                else:
                    new_quantity = inventory[id]['quantity']
                inventory[id]['quantity'] = new_quantity
            elif(choice == 3):
                new_price = input("Enter the new Price. ")
                if new_price != "":
                    new_price = float(new_price)
                else:
                    new_price = inventory[id]['price']

                new_quantity = input("Enter the new Quantity. ")
                if new_quantity != "":
                    new_quantity = int(new_quantity)
                else:
                    new_quantity = inventory[id]['quantity']

                inventory[id]['price'] = new_price
                inventory[id]['quantity'] = new_quantity
            print("\nVAlues Updated . ")
            save_inventory()
        except ValueError as e:
            print("Please Enter a integer as a choice. -_- ")
        except customError as e:
            print("Error Cought ! Please Enter a valid choice. -_- ")
    else:
        print("Id not found!")


def export_to_csv():
    with open("inventory_export.csv", mode="w", newline="") as file:
        writer = csv.writer(file)
        writer.writerow(["ID", "Name", "Price", "Quantity"])  # headers
        for id, item in inventory.items():
            writer.writerow([id, item["name"], item["price"], item["quantity"]])
    print("Inventory exported to inventory_export.csv ✅")


def cli_main():
    load_inventory()
    while True:
        try:
            print('\nWelcome to the Inverntry Management System. :) ')
            print("Please Select your option :- ")
            print('1. Add itme to inventry.')
            print('2. Remove itme to inventry.')
            print('3. Show itmes present in the inventry.')
            print('4. Search a perticular Itmen.')
            print('5. Update an Existing Item.')
            print('6. Export to csv.')
            print('7. Exit.')

            choice = int(input())
            if(choice == 1 ):
                add_item()
            elif(choice == 2):
                remove_itme()
            elif(choice == 3):
                Show_itme()
            elif(choice == 4):
                Search_item()
            elif(choice == 5):
                Update_item()
            elif(choice == 6):
                export_to_csv()
            elif(choice == 7):
                print("\n Exiting ... \n")
                break
            else:
                print('Please enter a valid choice -_-\n')
        except ValueError:
            print("Enter a valid Input")    

def start_gui():
    global root
    load_inventory()
    global item_Id
    root = tk.Tk()
    root.title("Inventory Management System")

    tk.Label(root, text="Inventory Management System", font=("Helvetica", 16)).grid(row=0, column=0, columnspan=3, pady=10)

    tk.Button(root, text="Add Item", width=15, command=gui_add_form).grid(row=1, column=0)
    tk.Button(root, text="Remove Item", width=15, command=gui_remove_form).grid(row=1, column=1)
    tk.Button(root, text="Update Item", width=15, command=gui_update_form).grid(row=1, column=2)
    tk.Button(root, text="Show Inventory", width=15, command=show_gui_inventory).grid(row=2, column=0)
    tk.Button(root, text="Export to CSV", width=15, command=export_to_csv).grid(row=2, column=1)
    tk.Button(root, text="Exit", width=15, command=root.destroy).grid(row=2, column=2)

    root.mainloop()



def Run_Selection():
    def launch_gui():
        root.destroy()
        start_gui()  # Your existing GUI function

    def launch_cli():
        root.destroy()
        cli_main()  # Your existing CLI function

    root = tk.Tk()
    root.title("Select Mode")
    root.geometry("300x120")

    label = tk.Label(root, text="Choose how to run the program:", font=("Arial", 12))
    label.pack(pady=10)

    gui_btn = tk.Button(root, text="GUI Mode", width=20, command=launch_gui)
    gui_btn.pack(pady=5)

    cli_btn = tk.Button(root, text="CLI Mode", width=20, command=launch_cli)
    cli_btn.pack(pady=5)

    root.mainloop()

#Run by default 
Run_Selection()
